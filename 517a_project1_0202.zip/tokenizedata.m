function tokenizedata(directory,output)

if nargin<1,directory='data/data_train';end;
if nargin<2,output='data_train';end;

%% tokenization (X)

% Uncomment these lines if you want to do tokenization yourself

fprintf('Running python tokenization script ...\n');
%system(['python tokenize.py ' directory ' 10 > spamdata.csv']);
system(['python tokenize.py ' directory]);
fprintf('Loading data ...\n');
%system(['python tokenize.py']);
M=load('spamdata.csv');

% normalize the colums to sum to 1
%X=sparse(M(:,2),M(:,1),ones(length(M),1));
X=sparse(M);
X=X*(spdiags(1./sum(X)',0,size(X,2),size(X,2)));
clear('M');

% Load in labels (do not change this part of the code)
[label,paths]=textread([directory '/index'],'%s %s');
Y=cellfun(@(x) isequal(x,'spam')*2-1,label,'UniformOutput',true)';    
clear('label');

save([output '.mat'],'X','Y');

%vis_rocs


