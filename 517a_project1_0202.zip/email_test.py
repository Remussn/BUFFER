"""
 Email model test
"""
import email
import os,sys

#path='E:/xdocuments/Courses/2018_Spring/CSE517A_Machine_Learning/Projects/project1/data/data_train/spam_2/'
#em=open(path+'00001.317e78fa8ee2f54cd4890fdc09ba8176').read()
fp = open("E:/xdocuments/Courses/2018_Spring/CSE517A_Machine_Learning/Projects/project1/data/data_train/spam_2/00001.317e78fa8ee2f54cd4890fdc09ba8176", "r")
msg = email.message_from_file(fp) # 直接文件创建message对象，这个时候也会做初步的解码
subject = msg.get("subject") # 取信件头里的subject,　也就是主题
print(subject)